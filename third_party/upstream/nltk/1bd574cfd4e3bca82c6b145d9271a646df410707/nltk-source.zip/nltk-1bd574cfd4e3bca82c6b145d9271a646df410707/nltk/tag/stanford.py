# Natural Language Toolkit: Interface to the Stanford Part-of-speech and Named-Entity Taggers
#
# Copyright (C) 2001-2026 NLTK Project
# Author: Nitin Madnani <nmadnani@ets.org>
#         Rami Al-Rfou' <ralrfou@cs.stonybrook.edu>
# URL: <https://www.nltk.org/>
# For license information, see LICENSE.TXT

"""
A module for interfacing with the Stanford taggers.

Tagger models need to be downloaded from https://nlp.stanford.edu/software
and the STANFORD_MODELS environment variable set (a colon-separated
list of paths).

For more details see the documentation for StanfordPOSTagger and StanfordNERTagger.
"""

import os
import tempfile
import warnings
from abc import abstractmethod
from subprocess import PIPE

from nltk import pathsec
from nltk.data import staging_tempdir
from nltk.internals import find_file, find_jar, java
from nltk.pathsec import has_line_unsafe_char
from nltk.pathsec import open as pathsec_open
from nltk.pathsec import validate_tool_path
from nltk.tag.api import TaggerI

_stanford_url = "https://nlp.stanford.edu/software"


class StanfordTagger(TaggerI):
    """
    An interface to Stanford taggers. Subclasses must define:

    - ``_cmd`` property: A property that returns the command that will be
      executed.
    - ``_SEPARATOR``: Class constant that represents that character that
      is used to separate the tokens from their tags.
    - ``_JAR`` file: Class constant that represents the jar file name.
    """

    _SEPARATOR = ""
    _JAR = ""

    def __init__(
        self,
        model_filename,
        path_to_jar=None,
        encoding="utf8",
        verbose=False,
        java_options="-mx1000m",
    ):
        # Raise deprecation warning.
        warnings.warn(
            str(
                "\nThe StanfordTokenizer will "
                "be deprecated in version 3.2.6.\n"
                "Please use \033[91mnltk.parse.corenlp.CoreNLPParser\033[0m instead."
            ),
            DeprecationWarning,
            stacklevel=2,
        )

        if not self._JAR:
            warnings.warn(
                "The StanfordTagger class is not meant to be "
                "instantiated directly. Did you mean "
                "StanfordPOSTagger or StanfordNERTagger?"
            )
        self._stanford_jar = find_jar(
            self._JAR, path_to_jar, searchpath=(), url=_stanford_url, verbose=verbose
        )

        self._stanford_model = find_file(
            model_filename, env_vars=("STANFORD_MODELS",), verbose=verbose
        )
        # Fail fast: the model is a JVM subprocess argument, so bound it here as
        # well as at the hand-off, refuse a tamperable or oversized model, and
        # keep only the checked string, never an out-of-sandbox path or object.
        self._stanford_model = validate_tool_path(
            self._stanford_model,
            context=f"{type(self).__name__}",
            max_bytes=pathsec.MAX_TOOL_MODEL_BYTES,
            require_private=True,
        )

        self._encoding = encoding
        self.java_options = java_options

    @property
    @abstractmethod
    def _cmd(self):
        """
        A property that returns the command that will be executed.
        """

    def tag(self, tokens):
        # This function should return list of tuple rather than list of list
        return sum(self.tag_sents([tokens]), [])

    def tag_sents(self, sentences):
        encoding = self._encoding

        # A line break in a token would inject an extra input line and silently
        # mislabel output (parse_output re-aligns tags by sentence); a tab, NUL
        # or other control character would be re-split or truncated by the
        # tool. Refuse them by the shared line-safety rule, then build the
        # input once and require exactly one separator per sentence gap.
        for sentence in sentences:
            for token in sentence:
                if has_line_unsafe_char(token):
                    raise ValueError(
                        "Tokens cannot contain newline characters, nor a tab, "
                        "another line break, a control character or NUL: %r" % (token,)
                    )
        _input = "\n".join(" ".join(x) for x in sentences)
        if _input.count("\n") != max(len(sentences) - 1, 0) or "\r" in _input:
            raise ValueError("Tokens cannot contain newline characters.")

        input_file_path = None
        java_succeeded = False
        try:
            # Create a temporary input file
            _input_fh, input_file_path = tempfile.mkstemp(
                text=True, dir=staging_tempdir()
            )
            self._input_file_path = input_file_path

            # The model is handed to the JVM subprocess pathsec.open cannot wrap:
            # re-check it and freeze the checked string BEFORE _cmd reads it, so
            # the argv never carries a swapped or re-resolving value (GHSA-8mgp).
            self._stanford_model = validate_tool_path(
                self._stanford_model,
                context="StanfordTagger.tag_sents",
                max_bytes=pathsec.MAX_TOOL_MODEL_BYTES,
                require_private=True,
            )
            cmd = list(self._cmd)
            cmd.extend(["-encoding", encoding])

            # mkstemp gives a race-free path inside the pathsec-validated 0700
            # staging dir; reopen it through pathsec_open (the same chokepoint the
            # rest of nltk stages tool input through) rather than the raw fd.
            os.close(_input_fh)
            if isinstance(_input, str) and encoding:
                _input = _input.encode(encoding)
            with pathsec_open(
                input_file_path, "wb", context="StanfordTagger.tag_sents"
            ) as input_fh:
                input_fh.write(_input)

            # Run the tagger and get the output
            stanpos_output, _stderr = java(
                cmd,
                classpath=self._stanford_jar,
                stdout=PIPE,
                stderr=PIPE,
                options=self.java_options,
            )
            # java() returns text (universal_newlines=True), so only decode when
            # an older/bytes-returning path is in play.
            if isinstance(stanpos_output, bytes):
                stanpos_output = stanpos_output.decode(encoding)
            java_succeeded = True
        finally:
            if input_file_path:
                try:
                    os.unlink(input_file_path)
                except FileNotFoundError:
                    pass
                except OSError:
                    if java_succeeded:
                        raise

        return self.parse_output(stanpos_output, sentences)

    def parse_output(self, text, sentences=None):
        # Output the tagged sentences
        tagged_sentences = []
        for tagged_sentence in text.strip().split("\n"):
            sentence = []
            for tagged_word in tagged_sentence.strip().split():
                word_tags = tagged_word.strip().split(self._SEPARATOR)
                sentence.append(
                    ("".join(word_tags[:-1]), word_tags[-1].replace("0", "").upper())
                )
            tagged_sentences.append(sentence)
        return tagged_sentences


class StanfordPOSTagger(StanfordTagger):
    """
    A class for pos tagging with Stanford Tagger. The input is the paths to:
     - a model trained on training data
     - (optionally) the path to the stanford tagger jar file. If not specified here,
       then this jar file must be specified in the CLASSPATH environment variable.
     - (optionally) the encoding of the training data (default: UTF-8)

    Example:

        >>> from nltk.tag import StanfordPOSTagger
        >>> st = StanfordPOSTagger('english-bidirectional-distsim.tagger') # doctest: +SKIP
        >>> st.tag('What is the airspeed of an unladen swallow ?'.split()) # doctest: +SKIP
        [('What', 'WP'), ('is', 'VBZ'), ('the', 'DT'), ('airspeed', 'NN'), ('of', 'IN'), ('an', 'DT'), ('unladen', 'JJ'), ('swallow', 'VB'), ('?', '.')]
    """

    _SEPARATOR = "_"
    _JAR = "stanford-postagger.jar"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @property
    def _cmd(self):
        return [
            "edu.stanford.nlp.tagger.maxent.MaxentTagger",
            "-model",
            self._stanford_model,
            "-textFile",
            self._input_file_path,
            "-tokenize",
            "false",
            "-outputFormatOptions",
            "keepEmptySentences",
        ]


class StanfordNERTagger(StanfordTagger):
    """
    A class for Named-Entity Tagging with Stanford Tagger. The input is the paths to:

    - a model trained on training data
    - (optionally) the path to the stanford tagger jar file. If not specified here,
      then this jar file must be specified in the CLASSPATH environment variable.
    - (optionally) the encoding of the training data (default: UTF-8)

    Example:

        >>> from nltk.tag import StanfordNERTagger
        >>> st = StanfordNERTagger('english.all.3class.distsim.crf.ser.gz') # doctest: +SKIP
        >>> st.tag('Rami Eid is studying at Stony Brook University in NY'.split()) # doctest: +SKIP
        [('Rami', 'PERSON'), ('Eid', 'PERSON'), ('is', 'O'), ('studying', 'O'),
         ('at', 'O'), ('Stony', 'ORGANIZATION'), ('Brook', 'ORGANIZATION'),
         ('University', 'ORGANIZATION'), ('in', 'O'), ('NY', 'LOCATION')]
    """

    _SEPARATOR = "/"
    _JAR = "stanford-ner.jar"
    _FORMAT = "slashTags"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @property
    def _cmd(self):
        # Adding -tokenizerFactory edu.stanford.nlp.process.WhitespaceTokenizer -tokenizerOptions tokenizeNLs=false for not using stanford Tokenizer
        return [
            "edu.stanford.nlp.ie.crf.CRFClassifier",
            "-loadClassifier",
            self._stanford_model,
            "-textFile",
            self._input_file_path,
            "-outputFormat",
            self._FORMAT,
            "-tokenizerFactory",
            "edu.stanford.nlp.process.WhitespaceTokenizer",
            "-tokenizerOptions",
            '"tokenizeNLs=false"',
        ]

    def parse_output(self, text, sentences):
        if self._FORMAT == "slashTags":
            # Joint together to a big list
            tagged_sentences = []
            for tagged_sentence in text.strip().split("\n"):
                for tagged_word in tagged_sentence.strip().split():
                    word_tags = tagged_word.strip().split(self._SEPARATOR)
                    tagged_sentences.append(("".join(word_tags[:-1]), word_tags[-1]))

            # Separate it according to the input
            result = []
            start = 0
            for sent in sentences:
                result.append(tagged_sentences[start : start + len(sent)])
                start += len(sent)
            return result

        raise NotImplementedError
