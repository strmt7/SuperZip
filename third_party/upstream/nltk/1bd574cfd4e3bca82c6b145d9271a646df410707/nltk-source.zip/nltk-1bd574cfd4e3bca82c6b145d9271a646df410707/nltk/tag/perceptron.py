# This module is a port of the Textblob Averaged Perceptron Tagger
# Author: Matthew Honnibal <honnibal+gh@gmail.com>,
#         Long Duong <longdt219@gmail.com> (NLTK port)
# URL: <https://github.com/sloria/textblob-aptagger>
#      <https://www.nltk.org/>
# Copyright 2013 Matthew Honnibal
# NLTK modifications Copyright 2015 The NLTK Project
#
# This module is provided under the terms of the MIT License.

import errno
import json
import logging
import os
import random
from collections import defaultdict
from os.path import join as path_join
from pathlib import Path
from tempfile import gettempdir

from nltk import jsontags
from nltk.data import (
    FileSystemPathPointer,
    find,
    make_staging_dir,
    open_datafile,
)
from nltk.jsontags import safe_json_load
from nltk.pathsec import _fd_realpath
from nltk.pathsec import open as pathsec_open
from nltk.pathsec import validate_path, validate_tool_dir, validate_tool_path
from nltk.tag.api import TaggerI
from nltk.termsec import safe_print

# The training progress line goes to this module's own logger, as the other
# NLTK modules that log do, not to the root logger through logging.info():
# a library must not configure or write straight into the root logger.
_logger = logging.getLogger(__name__)


def _validate_name_component(value, kind="language code"):
    """Refuse a value that is really a path where a filename fragment is meant.

    The model filenames are built by interpolation and then opened *relative to
    a pinned directory descriptor*. ``O_NOFOLLOW`` and the fd only anchor the
    base: a ``..`` inside the name walks out of the verified directory and
    writes anywhere the process can reach, so both halves of the name (the
    ``lang`` and the ``TAGGER_NAME`` prefix) escaped the sandbox (CWE-22).
    Applied to the composed filename as well as to each part, so a future
    interpolation is covered without a new check.
    """
    text = str(value)
    if (
        not text
        or not text.strip()
        or text in (".", "..")
        or "\x00" in text
        or "/" in text
        or "\\" in text
        or os.sep in text
        or (os.altsep and os.altsep in text)
    ):
        raise ValueError(
            f"Invalid tagger {kind} {value!r}: must be a single filename "
            "component (no path separators, '..' or NUL)"
        )
    return text


def _open_private_model_dir(loc):
    """Create/reuse *loc* as a private directory and return a pinned O_NOFOLLOW
    directory descriptor, closing the shared-temp symlink squat / TOCTOU race.

    The leaf is created with ``os.mkdir`` (atomic: it either creates the real
    directory or fails with ``FileExistsError``) and then re-opened with
    ``O_NOFOLLOW|O_DIRECTORY``; so a symlink pre-planted or raced in at the
    guessable default name is refused (``ELOOP``/``ENOTDIR``) instead of being
    followed. The descriptor is rejected unless it is a real directory owned by
    the current user and not group-/world-writable (CWE-59/377/378).
    """
    parent = os.path.dirname(loc) or "."
    os.makedirs(parent, exist_ok=True)
    try:
        os.mkdir(loc, 0o700)
    except FileExistsError:
        pass
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(loc, flags)
    except OSError as e:
        if e.errno in (errno.ELOOP, errno.ENOTDIR):
            raise PermissionError(
                f"Refusing trained-model dir {loc!r}: not a real directory "
                "(symlink / TOCTOU squat) (CWE-59)"
            ) from e
        raise
    try:
        st = os.fstat(fd)
        # POSIX only: on Windows st_uid is not meaningful and NTFS ACLs govern.
        if os.name == "posix" and (st.st_uid != os.getuid() or (st.st_mode & 0o022)):
            raise PermissionError(
                f"Refusing non-private trained-model dir {loc!r}: not owned by "
                "you or group-/world-writable (CWE-377/378)"
            )
        # Validate where the descriptor actually landed, not the string: the
        # containment check ran before this open, so an intermediate directory
        # swapped in between the two would otherwise pin an outside directory.
        landed = _fd_realpath(fd)
        validate_path(
            landed if landed is not None else os.path.realpath(loc),
            context="PerceptronTagger.save_to_json",
        )
    except BaseException:
        os.close(fd)
        raise
    return fd


try:
    import numpy as np
except ImportError:
    pass


@jsontags.register_tag
class AveragedPerceptron:
    """An averaged perceptron, as implemented by Matthew Honnibal.

    See more implementation details here:
        https://explosion.ai/blog/part-of-speech-pos-tagger-in-python
    """

    json_tag = "nltk.tag.perceptron.AveragedPerceptron"

    def __init__(self, weights=None):
        # Each feature gets its own weight vector, so weights is a dict-of-dicts
        self.weights = weights if weights else {}
        self.classes = set()
        # The accumulated values, for the averaging. These will be keyed by
        # feature/clas tuples
        self._totals = defaultdict(int)
        # The last time the feature was changed, for the averaging. Also
        # keyed by feature/clas tuples
        # (tstamps is short for timestamps)
        self._tstamps = defaultdict(int)
        # Number of instances seen
        self.i = 0

    def _softmax(self, scores):
        s = np.fromiter(scores.values(), dtype=float)
        exps = np.exp(s)
        return exps / np.sum(exps)

    def predict(self, features, return_conf=False):
        """Dot-product the features and current weights and return the best label."""
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            weights = self.weights[feat]
            for label, weight in weights.items():
                scores[label] += value * weight

        # Do a secondary alphabetic sort, for stability
        best_label = max(self.classes, key=lambda label: (scores[label], label))
        # compute the confidence
        conf = max(self._softmax(scores)) if return_conf else None

        return best_label, conf

    def update(self, truth, guess, features):
        """Update the feature weights."""

        def upd_feat(c, f, w, v):
            param = (f, c)
            self._totals[param] += (self.i - self._tstamps[param]) * w
            self._tstamps[param] = self.i
            self.weights[f][c] = w + v

        self.i += 1
        if truth == guess:
            return None
        for f in features:
            weights = self.weights.setdefault(f, {})
            upd_feat(truth, f, weights.get(truth, 0.0), 1.0)
            upd_feat(guess, f, weights.get(guess, 0.0), -1.0)

    def average_weights(self):
        """Average weights from all iterations."""
        for feat, weights in self.weights.items():
            new_feat_weights = {}
            for clas, weight in weights.items():
                param = (feat, clas)
                total = self._totals[param]
                total += (self.i - self._tstamps[param]) * weight
                averaged = round(total / self.i, 3)
                if averaged:
                    new_feat_weights[clas] = averaged
            self.weights[feat] = new_feat_weights

    def save(self, path):
        """Save the model weights as json.

        ``path`` is caller-supplied, so the write goes through the pathsec
        sandbox: a destination outside the allowed NLTK data roots (or a symlink
        planted at one) is refused before any bytes are written, instead of the
        builtin ``open`` that made this an arbitrary-file write
        (GHSA-8mgp-746c-j5xp).
        """
        validate_tool_path(path, context="AveragedPerceptron.save", must_exist=False)
        with pathsec_open(path, "w", context="AveragedPerceptron.save") as fout:
            return json.dump(self.weights, fout)

    def load(self, path):
        """Load the json model weights.

        The read is sandboxed for the same reason as :meth:`save`: a model path
        outside the allowed roots is refused rather than read back to the caller
        (GHSA-8mgp-746c-j5xp).
        """
        # Refuse a planted FIFO/socket/device before pathsec.open blocks on it.
        validate_tool_path(path, context="AveragedPerceptron.load")
        with pathsec_open(path, context="AveragedPerceptron.load") as fin:
            # Bound size and nesting depth before the recursive C decoder runs:
            # a model file with a raised recursion limit could otherwise
            # segfault the interpreter (uncatchable) on deeply nested JSON.
            self.weights = safe_json_load(fin, context="AveragedPerceptron.load")

    def encode_json_obj(self):
        return self.weights

    @classmethod
    def decode_json_obj(cls, obj):
        return cls(obj)


@jsontags.register_tag
class PerceptronTagger(TaggerI):
    """
    Greedy Averaged Perceptron tagger, as implemented by Matthew Honnibal.
    See more implementation details here:
    https://explosion.ai/blog/part-of-speech-pos-tagger-in-python

    >>> from nltk.tag.perceptron import PerceptronTagger
    >>> tagger = PerceptronTagger(load=False)

    Train and save the model:

    >>> tagger.train([[('today','NN'),('is','VBZ'),('good','JJ'),('day','NN')],
    ... [('yes','NNS'),('it','PRP'),('beautiful','JJ')]], save_loc=tagger.save_dir)

    Load the saved model:

    >>> from nltk.data import FileSystemPathPointer
    >>> tagger2 = PerceptronTagger(loc=FileSystemPathPointer(tagger.save_dir))
    >>> print(sorted(list(tagger2.classes)))
    ['JJ', 'NN', 'NNS', 'PRP', 'VBZ']

    >>> print(tagger2.classes == tagger.classes)
    True

    >>> tagger2.tag(['today','is','a','beautiful','day'])
    [('today', 'NN'), ('is', 'PRP'), ('a', 'PRP'), ('beautiful', 'JJ'), ('day', 'NN')]

    Use the pretrain model (the default constructor)

    >>> pretrain = PerceptronTagger()

    >>> pretrain.tag('The quick brown fox jumps over the lazy dog'.split())
    [('The', 'DT'), ('quick', 'JJ'), ('brown', 'NN'), ('fox', 'NN'), ('jumps', 'VBZ'), ('over', 'IN'), ('the', 'DT'), ('lazy', 'JJ'), ('dog', 'NN')]

    >>> pretrain.tag("The red cat".split())
    [('The', 'DT'), ('red', 'JJ'), ('cat', 'NN')]
    """

    json_tag = "nltk.tag.perceptron.PerceptronTagger"

    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, load=True, lang="eng", loc=None):
        """
        :param load: Load the json model upon instantiation.
        """
        self.model = AveragedPerceptron()
        self.tagdict = {}
        self.classes = set()
        self.lang = lang
        # Retained for backward compatibility; save_dir no longer derives from it.
        self.TRAINED_TAGGER_PATH = gettempdir()
        self.TAGGER_NAME = "averaged_perceptron_tagger"
        self._save_dir = None
        if load:
            self.load_from_json(lang, loc)

    @property
    def save_dir(self):
        """This tagger's private directory for saved model artifacts.

        Allocated lazily by ``nltk.data.make_staging_dir`` INSIDE an allowed data
        root, with an unpredictable name and mode 0700. Because it already lives
        in the pathsec sandbox, saving and loading a trained model needs no
        widening of ``nltk.data.path``, and unlike the old guessable
        ``<tempdir>/averaged_perceptron_tagger_<lang>``, another local user
        cannot pre-create or symlink it to redirect the write (CWE-377/378).
        """
        if self._save_dir is None:
            # Both parts land in a mkdtemp prefix, which is concatenated onto
            # the data root, so a path-shaped part stages output outside it.
            _validate_name_component(self.lang, "language code")
            _validate_name_component(self.TAGGER_NAME, "tagger name")
            self._save_dir = make_staging_dir(
                prefix=f"nltk_{self.TAGGER_NAME}_{self.lang}_"
            )
        return self._save_dir

    def param_files(self, lang="eng"):
        # The one place lang and TAGGER_NAME become filenames, so validate the
        # composed name here rather than each ingredient at each caller.
        _validate_name_component(lang, "language code")
        return tuple(
            _validate_name_component(
                f"{self.TAGGER_NAME}_{lang}.{attr}.json", "model filename"
            )
            for attr in ("weights", "tagdict", "classes")
        )

    def tag(self, tokens, return_conf=False, use_tagdict=True):
        """
        Tag tokenized sentences.
        :params tokens: list of word
        :type tokens: list(str)
        """
        prev, prev2 = self.START
        output = []

        context = self.START + [self.normalize(w) for w in tokens] + self.END
        for i, word in enumerate(tokens):
            tag, conf = (self.tagdict.get(word), 1.0) if use_tagdict else (None, None)
            if not tag:
                features = self._get_features(i, word, context, prev, prev2)
                tag, conf = self.model.predict(features, return_conf)
            output.append((word, tag, conf) if return_conf else (word, tag))

            prev2 = prev
            prev = tag

        return output

    def train(self, sentences, save_loc=None, nr_iter=5):
        """Train a model from sentences, and save it at ``save_loc``. ``nr_iter``
        controls the number of Perceptron training iterations.

        :param sentences: A list or iterator of sentences, where each sentence
            is a list of (words, tags) tuples.
        :param save_loc: If not ``None``, saves a json model in this location.
        :param nr_iter: Number of training iterations.
        """
        # We'd like to allow ``sentences`` to be either a list or an iterator,
        # the latter being especially important for a large training dataset.
        # Because ``self._make_tagdict(sentences)`` runs regardless, we make
        # it populate ``self._sentences`` (a list) with all the sentences.
        # This saves the overheard of just iterating through ``sentences`` to
        # get the list by ``sentences = list(sentences)``.

        self._sentences = list()  # to be populated by self._make_tagdict...
        self._make_tagdict(sentences)
        self.model.classes = self.classes
        for iter_ in range(nr_iter):
            c = 0
            n = 0
            for sentence in self._sentences:
                words, tags = zip(*sentence)

                prev, prev2 = self.START
                context = self.START + [self.normalize(w) for w in words] + self.END
                for i, word in enumerate(words):
                    guess = self.tagdict.get(word)
                    if not guess:
                        feats = self._get_features(i, word, context, prev, prev2)
                        guess, _ = self.model.predict(feats)
                        self.model.update(tags[i], guess, feats)
                    prev2 = prev
                    prev = guess
                    c += guess == tags[i]
                    n += 1
            random.shuffle(self._sentences)
            _logger.info("Iter %r: %r/%r=%r", iter_, c, n, _pc(c, n))

        # We don't need the training sentences anymore, and we don't want to
        # waste space on them when we the trained tagger.
        self._sentences = None

        self.model.average_weights()
        # Save to json files.
        if save_loc is not None:
            self.save_to_json(lang=self.lang, loc=save_loc)

    def save_to_json(self, lang="xxx", loc=None):
        # Fail before any directory is created, not once the fd is pinned.
        _validate_name_component(lang, "language code")
        if not loc:
            loc = self.save_dir
        # A caller-supplied destination is an unbounded write primitive otherwise:
        # the helper below happily os.makedirs() a whole chain anywhere writable.
        validate_tool_dir(loc, context="PerceptronTagger.save_to_json")
        # The default loc (save_dir) is an unpredictable 0700 dir inside a data
        # root, but a caller may still pass any in-sandbox path here, so the
        # atomic checks below stay: a local attacker could pre-plant or race a
        # symlink at a caller-chosen ``loc``. A plain
        # ``islink`` pre-check is non-atomic (TOCTOU) and misses it once created;
        # ``_open_private_model_dir`` instead creates/re-opens the leaf atomically
        # with O_NOFOLLOW|O_DIRECTORY, verifies it is a real, user-owned,
        # non-world-writable directory, and returns a pinned fd we write relative
        # to (CWE-59/377/378).
        #
        # On Windows ``%TEMP%`` is per-user and ACL-protected (no such squat), and
        # ``os.open`` cannot open a directory as a descriptor there, so use a
        # plain create + write.
        if os.name != "posix":
            os.makedirs(loc, exist_ok=True)
            for param, json_file in zip(self.encode_json_obj(), self.param_files(lang)):
                with pathsec_open(
                    path_join(loc, json_file),
                    "w",
                    context="PerceptronTagger.save_to_json",
                ) as fout:
                    json.dump(param, fout)
            return

        dir_fd = _open_private_model_dir(loc)
        try:

            # Write each model file relative to the pinned directory fd (where
            # supported) with O_NOFOLLOW (0600), so neither the dir nor the file
            # can be redirected outside the verified directory after the check.
            # Not pathsec.open: a dir-fd-relative name has no absolute path to
            # validate, and the pinned fd is strictly stronger than a path check.
            use_dir_fd = os.open in os.supports_dir_fd

            def _no_follow_opener(path, flags):
                extra = {"dir_fd": dir_fd} if use_dir_fd else {}
                return os.open(
                    path, flags | getattr(os, "O_NOFOLLOW", 0), 0o600, **extra
                )

            for param, json_file in zip(self.encode_json_obj(), self.param_files(lang)):
                target = json_file if use_dir_fd else path_join(loc, json_file)
                # No builtin open(): take the hardened descriptor straight from
                # the opener and wrap it, so the write still goes through the
                # pinned dir_fd with O_NOFOLLOW and nothing re-resolves the name.
                fd = _no_follow_opener(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC)
                with os.fdopen(fd, "w") as fout:
                    json.dump(param, fout)
        finally:
            os.close(dir_fd)

    def load_from_json(self, lang="eng", loc=None):
        # Automatically find path to the tagger if location is not specified.
        # loc can refer to zip or real FS
        # Symmetric with save_to_json: lang reaches find() as a resource name and
        # param_files() as a filename, so reject a path-shaped one up front.
        _validate_name_component(lang, "language code")
        if isinstance(loc, bytes):
            loc = os.fsdecode(loc)
        if isinstance(loc, (str, Path)) and not str(loc).strip():
            # Windows strips trailing spaces from a path component, so a blank
            # loc silently resolves to the data root itself instead of failing.
            raise ValueError(
                f"Invalid tagger model location {loc!r}: blank path names no model"
            )
        if loc is None:
            loc = find(f"taggers/averaged_perceptron_tagger_{lang}/")
        elif isinstance(loc, str):
            # Backward compatible:
            # - absolute paths are explicit filesystem locations
            # - relative strings are treated as NLTK resource names and resolved via find()
            if os.path.isabs(loc):
                # Bound it here, not at the eventual read: FileSystemPathPointer
                # stats the path, so an unbounded loc is an existence oracle too.
                validate_tool_dir(loc, context="PerceptronTagger.load_from_json")
                loc = FileSystemPathPointer(loc)
            else:
                loc = find(loc)
        elif isinstance(loc, Path):
            # Explicit filesystem path
            validate_tool_dir(str(loc), context="PerceptronTagger.load_from_json")
            loc = FileSystemPathPointer(str(loc))
        # else: assume loc is already a PathPointer (zip or filesystem)

        # No sandbox widening here: save_dir is allocated inside a data root, so a
        # model NLTK saved is already readable. Any other loc must be authorized by
        # the application, since trusting a caller path would disarm pathsec.
        def load_param(json_file):
            with open_datafile(loc, json_file) as fin:
                # Same bounded parse as AveragedPerceptron.load: reject an
                # over-deep or over-large param file before the C decoder can
                # crash on it, without touching legit (shallow) model shapes.
                return safe_json_load(fin, context="PerceptronTagger.load_from_json")

        self.decode_json_params(
            load_param(js_file) for js_file in self.param_files(lang)
        )

    def decode_json_params(self, params):
        weights, tagdict, class_list = params
        self.model.weights = weights
        self.tagdict = tagdict
        self.classes = self.model.classes = set(class_list)

    def encode_json_obj(self):
        return self.model.weights, self.tagdict, list(self.classes)

    @classmethod
    def decode_json_obj(cls, obj):
        tagger = cls(load=False)
        tagger.decode_json_params(obj)
        return tagger

    def normalize(self, word):
        """
        Normalization used in pre-processing.
        - All words are lower cased
        - Groups of digits of length 4 are represented as !YEAR;
        - Other digits are represented as !DIGITS

        :rtype: str
        """
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _get_features(self, i, word, context, prev, prev2):
        """Map tokens into a feature representation, implemented as a
        {hashable: int} dict. If the features change, a new model must be
        trained.
        """

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(self.START)
        features = defaultdict(int)
        # It's useful to have a constant feature, which acts sort of like a prior
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def _make_tagdict(self, sentences):
        """
        Make a tag dictionary for single-tag words.
        :param sentences: A list of list of (word, tag) tuples.
        """
        counts = defaultdict(lambda: defaultdict(int))
        for sentence in sentences:
            self._sentences.append(sentence)
            for word, tag in sentence:
                counts[word][tag] += 1
                self.classes.add(tag)
        freq_thresh = 20
        ambiguity_thresh = 0.97
        for word, tag_freqs in counts.items():
            tag, mode = max(tag_freqs.items(), key=lambda item: item[1])
            n = sum(tag_freqs.values())
            # Don't add rare words to the tag dictionary
            # Only add quite unambiguous words
            if n >= freq_thresh and (mode / n) >= ambiguity_thresh:
                self.tagdict[word] = tag


def _pc(n, d):
    return (n / d) * 100


def _train_and_test(lang="sv"):
    """
    Train and test on 'lang' part of universal_treebanks corpus, which includes
    train and test sets in conll format for 'de', 'es', 'fi', 'fr' and 'sv'.
    Finds 0.94 accuracy on 'sv' (Swedish) test set.
    """
    from nltk.corpus import universal_treebanks as utb

    tagger = PerceptronTagger(load=False, lang=lang)
    training = utb.tagged_sents(f"ch/{lang}/{lang}-universal-ch-train.conll")
    testing = utb.tagged_sents(f"ch/{lang}/{lang}-universal-ch-test.conll")
    safe_print(
        f"(Lang = {lang}) training on {len(training)} and testing on {len(testing)} sentences"
    )
    # Train and save the model
    tagger.train(training, save_loc=tagger.save_dir)
    safe_print("Accuracy : ", tagger.accuracy(testing))


if __name__ == "__main__":
    _train_and_test()
