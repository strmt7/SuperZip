"""Shared machinery for the per-advisory security probes.

Each ``ghsa_*`` module registers one probe with ``@probe("GHSA-...")``. A probe
runs the attack the advisory describes and returns ``(status, evidence)``:

    FIXED       attack ran, tree defended
    VULNERABLE  attack ran and worked -- a regression
    STATIC      guard confirmed in source, attack not executed (needs a
                network peer / real download / running JVM)
    BENIGN      audited, never exploitable here, pinned so it stays that way

This package lives inside ``nltk/test/unit`` so the coverage test imports it as
a normal sibling -- it never computes an outside path or touches ``sys.path``,
which in an installed tree would reach ``site-packages``. ``read_source`` reads a
module's own ``__file__`` for the same reason.
"""

import importlib
import io  # noqa: F401  (re-exported for probe bodies)
import os
import pathlib
import shutil
import socket  # noqa: F401
import tempfile

FIXED = "FIXED"
VULNERABLE = "VULNERABLE"
STATIC = "STATIC"
BENIGN = "BENIGN"

#: Hostile payloads must not finish inside this. Generous so a loaded CI runner
#: does not flake to a false VULNERABLE.
DOS_BUDGET = 15.0

#: GHSA id -> probe callable, populated as each module is imported.
PROBES = {}


def probe(ghsa):
    """Register a probe returning (status, evidence)."""

    def register(func):
        if ghsa in PROBES:
            raise RuntimeError("duplicate probe for %s" % ghsa)
        PROBES[ghsa] = func
        return func

    return register


from nltk.test.unit import timing

#: An op whose big run spends less than this share of its wall time on the CPU
#: is mostly waiting, and its cost is judged on the wall clock instead.
CPU_BOUND_SHARE = timing.CPU_BOUND_SHARE
#: A scaling factor at or above this reads as super-linear (quadratic ~16x);
#: a linear sink stays near 4x, so the gap is wide on any machine.
QUADRATIC_RATIO = timing.QUADRATIC_RATIO
#: (CPU seconds, wall seconds) spent in a call. CPU time is what the
#: interpreter actually worked: descheduling by a loaded runner stretches only
#: the wall clock; a call that sleeps or waits on a child spends almost none.
timed_both = timing.cpu_and_wall
#: op(big) over op(small) in CPU time, paired by rep and normalised by a
#: calibration unit beside each sample (~4x linear, ~16x quadratic); the
#: history of the stalls and speed changes is in timing.scaling_ratio.
scaling_ratio = timing.scaling_ratio


def timed(func, *args):
    """Seconds charged to ``func(*args)``.

    Historically the wall clock; now the suite's shared rule in
    :mod:`nltk.test.unit.timing`: CPU time when the call computed, wall time
    when it waited, so a loaded runner cannot inflate a probe's measurement.
    """
    return timing.charged(func, *args)


def within_budget(func, budget=None, repeats=3):
    """Fastest of ``repeats`` runs of ``func``; ``(ok, seconds)``, ok if under budget.

    Absolute budget, not a doubling ratio: a pre-patch quadratic ran for
    tens of seconds on these payloads while the fixed code is milliseconds, so a
    generous budget separates them cleanly. Min-of-k because one sample on a
    loaded CI runner is noise, and a tight ratio there produced a false
    VULNERABLE. Contention only adds time, so the minimum is closest to truth.
    The seconds are the ones :mod:`nltk.test.unit.timing` charges: CPU time
    when the run computed, wall time when it waited. ``budget`` defaults to the
    module's ``DOS_BUDGET`` as it stands when the probe runs.
    """
    if budget is None:
        budget = DOS_BUDGET
    return timing.within_budget(func, budget, repeats)


def read_source(dotted_module):
    """Source of an importable NLTK module, via its own ``__file__``.

    ``Path.read_text`` closes the descriptor immediately instead of leaving the
    bare ``open()`` file object for the garbage collector to reclaim.
    """
    module = importlib.import_module(dotted_module)
    return pathlib.Path(module.__file__).read_text(encoding="utf-8")


def _outside_root_target():
    """A real file outside every pathsec-allowed root, plus a canary in it.

    Must be genuinely outside the allowed roots: on macOS the private system
    temp dir *is* an allowed root, so a temp file is not an escape target. A
    system file is. The canary must survive tokenisation/parsing, so it is a
    substring that appears verbatim in the file, not a word a reader would
    split.
    """
    for path, canary in (("/etc/passwd", "root:"), ("/etc/hosts", "localhost")):
        try:
            text = pathlib.Path(path).read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if canary in text:
            return path, canary
    return None, None


OUTSIDE_TARGET, OUTSIDE_CANARY = _outside_root_target()

#: Substrings that mark a rejection as a *security* decision rather than an
#: incidental failure (a missing file, a parse error). A probe may only report
#: FIXED when the attack was refused by one of these -- proving it reached the
#: guard -- or when the guard is disabled and it leaks.
_SECURITY_MARKERS = (
    "security",
    "violation",
    "pathsec",
    "unauthorized",
    "outside",
    "traversal",
    "must be relative",
    "unsafe",
)


def _restore_data_path(saved):
    """Undo any register_data_root() calls by restoring a saved nltk.data.path."""
    import nltk.data
    from nltk import pathsec

    nltk.data.path[:] = saved
    pathsec._ALLOWED_ROOTS_CACHE = None
    pathsec._LAST_DATA_PATHS = None


def register_data_root(root):
    """Register *root* as an nltk.data root and return an undo callable.

    A CorpusReader validates its root at __init__ against the pathsec data roots.
    On Linux tempfile.mkdtemp() lands in /tmp, which is NOT a data root (it is
    world-writable), so a probe that builds its corpus fixture there cannot even
    construct the reader and errors before exercising the escape guard. On macOS
    the private temp dir IS a root, which hid this. Registering the fixture root
    reflects how a real corpus lives -- inside a data root -- so the reader
    constructs and the traversal/symlink escapes are what actually get tested.
    """
    import nltk.data
    from nltk import pathsec

    saved = list(nltk.data.path)
    nltk.data.path.insert(0, root)
    pathsec._ALLOWED_ROOTS_CACHE = None
    pathsec._LAST_DATA_PATHS = None

    def _undo():
        nltk.data.path[:] = saved
        pathsec._ALLOWED_ROOTS_CACHE = None
        pathsec._LAST_DATA_PATHS = None

    return _undo


def is_security_rejection(exc):
    return any(marker in str(exc).lower() for marker in _SECURITY_MARKERS)


class Sandbox:
    """A corpus root holding a symlink to a real outside-root file."""

    def __init__(self):
        self.dir = tempfile.mkdtemp()
        self.root = os.path.join(self.dir, "corpus")
        os.makedirs(self.root, exist_ok=True)
        self.target = OUTSIDE_TARGET
        self.canary = OUTSIDE_CANARY
        self.link = os.path.join(self.root, "link.xml")
        try:
            os.symlink(OUTSIDE_TARGET or "/nonexistent", self.link)
        except OSError:
            self.link = None

    def cleanup(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def leaked(self, value):
        text = value if isinstance(value, str) else str(value)
        return bool(self.canary) and self.canary in text


def guard_rejects(guard):
    """Probe a containment guard directly with real outside-root paths.

    For readers whose public read needs a fully populated corpus, drive the
    guard function the advisory added instead: it must security-reject a
    symlink, an absolute path and a traversal that resolve outside the root.
    ``guard`` is ``fn(path, root)``; VULNERABLE if any passes, FIXED if all are
    security-rejected.
    """
    if not OUTSIDE_TARGET:
        return STATIC, "no readable outside-root target on this platform"
    box = Sandbox()
    try:
        cases = {
            "symlink": box.link,
            "absolute": OUTSIDE_TARGET,
            "traversal": os.path.join(box.root, "../" * 8 + OUTSIDE_TARGET.lstrip("/")),
        }
        notes = []
        for label, path in cases.items():
            if path is None:
                continue
            try:
                guard(path, box.root)
                return VULNERABLE, "%s path passed the guard" % label
            except Exception as exc:
                if not is_security_rejection(exc):
                    return STATIC, "{} rejected non-securely ({})".format(
                        label, type(exc).__name__
                    )
                notes.append(label)
        return FIXED, "guard security-rejects: " + ", ".join(notes)
    finally:
        box.cleanup()


def escape_probe(attempts):
    """Drive outside-root read attempts against a sandbox.

    ``attempts`` is a list of ``(label, fn(sandbox))``. Each fn tries to make a
    reader return the contents of a real outside-root file.

    * any fn returns the canary -> VULNERABLE (a genuine escape).
    * a fn refused by a security check -> that attempt reached the guard.
    * a fn that fails incidentally (missing file, parse error) never reached
      the sink; it is reported as such, not counted as a defence.

    FIXED requires at least one attempt to have been security-refused, so a
    probe cannot pass merely because every attack fizzled before the guard.
    """
    if not OUTSIDE_TARGET:
        return STATIC, "no readable outside-root target on this platform"
    box = Sandbox()
    try:
        reached, notes = False, []
        for label, run in attempts:
            try:
                result = run(box)
            except Exception as exc:
                if is_security_rejection(exc):
                    reached = True
                    notes.append(f"{label}=blocked({type(exc).__name__})")
                else:
                    notes.append(f"{label}=unreached({type(exc).__name__})")
                continue
            if box.leaked(result):
                return VULNERABLE, f"{label} read {box.target}"
            notes.append("%s=no-leak" % label)
        detail = "; ".join(notes)
        if reached:
            return FIXED, detail
        return STATIC, "attack never reached a security check: " + detail
    finally:
        box.cleanup()
